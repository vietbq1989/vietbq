<?php
class Magestore_Affiliateplus_Block_Updatebalancetransactions extends Mage_Core_Block_Template
{
	/**
	 * get Helper
	 *
	 * @return Magestore_Affiliateplus_Helper_Config
	 */
	public function _getHelper() {
		return Mage::helper('affiliateplus/config');
	}

	protected function _construct() {
		parent::_construct();
		$storeId = Mage::app()->getStore()->getId();
		// Changed By Adam 15/10/2014: Missing argument 1 for Magestore_Affiliateplus_Helper_Account::getStoreIdsByWebsite(), called in C:\xampp\htdocs\project\magento1.5.0.1\app\code\local\Magestore\Affiliateplus\Block\Sales\Standard.php on line 22 and defined  in C:\xampp\htdocs\project\magento1.5.0.1\app\code\local\Magestore\Affiliateplus\Helper\Account.php on line 156
		$websiteId = Mage::app()->getWebsite()->getId();
		$account = Mage::getSingleton('affiliateplus/session')->getAccount();
		$collection = Mage::getModel('affiliateplus/transaction')->getCollection();
		if ($this->_getHelper()->getSharingConfig('balance', $storeId) == 'store')
			$collection->addFieldToFilter('store_id', $storeId);
		elseif($this->_getHelper()->getSharingConfig('balance', $storeId) == 'website'){
			$storeIds = Mage::helper('affiliateplus/account')->getStoreIdsByWebsite($websiteId);
			$collection->addFieldToFilter('store_id', array('in'=>$storeIds));
		}
		$collection->addFieldToFilter('account_id', $account->getId())
			->addFieldToFilter('type', '10')
			->setOrder('created_time', 'DESC');

		$this->setCollection($collection);
	}

	public function _prepareLayout() {
		parent::_prepareLayout();
		$pager = $this->getLayout()->createBlock('page/html_pager', 'update_pager')
			->setTemplate('affiliateplus/html/pager.phtml')
			->setCollection($this->getCollection());
		$this->setChild('update_pager', $pager);

		$grid = $this->getLayout()->createBlock('affiliateplus/grid', 'update_grid');

		// prepare column
		$grid->addColumn('id', array(
			'header' => $this->__('No.'),
			'align' => 'left',
			'render' => 'getNoNumber',
		));

		$grid->addColumn('created_time', array(
			'header' => $this->__('Date'),
			'index' => 'created_time',
			'type' => 'date',
			'format' => 'medium',
			'align' => 'left',
			'searchable'    => true,
		));

		$grid->addColumn('order_item_names', array(
			'header' => $this->__('Products Name'),
			'index' => 'order_item_names',
			'align' => 'left',
			'render' => 'getFrontendProductHtmls',
			'searchable'    => true,
		));

		$grid->addColumn('total_amount', array(
			'header' => $this->__('Total Amount'),
			'align' => 'left',
			'type' => 'baseprice',
			'index' => 'total_amount',
		));

		$grid->addColumn('commission', array(
			'header' => $this->__('Commission'),
			'align' => 'left',
			'type' => 'baseprice',
			'index' => 'commission',
		));

		$grid->addColumn('status', array(
			'header' => $this->__('Status'),
			'align' => 'left',
			'index' => 'status',
			'width' => '95px',
			'type' => 'options',
			'options' => array(
				1 => $this->__('Complete'),
				2 => $this->__('Pending'),
				3 => $this->__('Canceled'),
				4 => $this->__('On Hold'),
			),
			'searchable'    => true,
		));

		$this->setChild('update_grid', $grid);
		return $this;
	}

	public function getNoNumber($row) {
		return sprintf('#%d', $row->getId());
	}

	public function getFrontendProductHtmls($row) {
		// return Mage::helper('affiliateplus')->getFrontendProductHtmls($row->getData('order_item_ids'));
		return Mage::helper('affiliateplus')->__('Balance adjusted');
	}

	public function getCommissionPlus($row) {
		$addCommission = $row->getPercentPlus() * $row->getCommission() / 100 + $row->getCommissionPlus();
		return Mage::helper('core')->currency($addCommission); //Mage::app()->getStore()->getBaseCurrency()->format($addCommission);
	}

	public function getPagerHtml() {
		return $this->getChildHtml('update_pager');
	}

	public function getGridHtml() {
		return $this->getChildHtml('update_grid');
	}

	protected function _toHtml() {
		$this->getChild('update_grid')->setCollection($this->getCollection());
		return parent::_toHtml();
	}

	public function getStatisticInfo() {
		$accountId = Mage::getSingleton('affiliateplus/session')->getAccount()->getId();
		$storeId = Mage::app()->getStore()->getId();
		$scope = Mage::getStoreConfig('affiliateplus/account/balance', $storeId);

		$collection = Mage::getModel('affiliateplus/transaction')->getCollection()
			->addFieldToFilter('account_id', $accountId)
			->addFieldToFilter('type', '10');

		$transactionTable = Mage::getModel('core/resource')->getTableName('affiliatepluslevel_transaction');
		if (Mage::helper('affiliateplus')->multilevelIsActive())
			$collection->getSelect()
				->joinLeft(array('ts' => $transactionTable), "ts.transaction_id = main_table.transaction_id", array('level' => 'level', 'plus_commission' => 'commission_plus'))
				->columns("if (ts.commission IS NULL, main_table.commission, ts.commission) as commission")
				->where("ts.tier_id=$accountId OR (ts.tier_id IS NULL AND main_table.account_id = $accountId )");
		/*edit by blanka*/
		if ($storeId && $scope == 'store')
			$collection->addFieldToFilter('store_id', $storeId);
		elseif($scope == 'website'){
			$websiteId = Mage::app()->getWebsite()->getId();
			$storeIds = Mage::helper('affiliateplus/account')->getStoreIdsByWebsite($websiteId);
			$collection->addFieldToFilter('store_id', array('in'=>$storeIds));
		}
		/*end edit*/

		$totalCommission = 0;

		foreach ($collection as $item) {
			if ($item->getStatus() == 1) {
				$totalCommission += $item->getCommission();
				if ($item->getPlusCommission())
					$totalCommission += $item->getPlusCommission();
				else
					$totalCommission += $item->getCommissionPlus() + $item->getCommission() * $item->getPercentPlus() / 100;
			}
		}
		return array(
			'number_commission' => count($collection),
			'transactions' => $this->__('Update Transactions'),
			'commissions' => $totalCommission,
			'earning' => $this->__('Update Balance')
		);
	}
}