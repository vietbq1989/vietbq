<?php
class Magestore_Affiliateplus_Block_Payment_Verify extends Mage_Core_Block_Template
{
    
}