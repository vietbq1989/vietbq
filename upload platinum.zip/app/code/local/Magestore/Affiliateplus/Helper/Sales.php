<?php

class Magestore_Affiliateplus_Helper_Sales extends Mage_Core_Helper_Abstract
{
	
}