<?php

class Magestore_Affiliateplus_Model_Action_Abstract extends Mage_Core_Model_Abstract
{
    
}